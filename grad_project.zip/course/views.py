from django.shortcuts import get_object_or_404, render
from django.http import HttpResponse
from django.template import loader

from .forms import CourseForm
from .models import Course
# Create your views here.

def index(request):
    return render(request, 'course/index.html')
    # return HttpResponse("Hello, world. You're at the timetable index.")

# def detail(request):
#     course_list = Course.objects
#     template = loader.get_template('course/detail.html')
#     context = {'course_list': course_list}
#     return HttpResponse("You're looking at course detail")

def detail(request):
    course_list = Course.objects.all()
    template = loader.get_template('course/detail.html')
    context = {'course_list': course_list}
    return render(request, 'course/detail.html', context)

def addcourse(request):
    form = CourseForm(request.POST or None)
    if form.is_valid():
        form.save()
        form = CourseForm()
    context = {
        'form': form
    }
    return render(request, 'course/addcourse.html', context)