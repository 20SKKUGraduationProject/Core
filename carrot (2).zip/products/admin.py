from django.contrib import admin

# Register your models here.
from .models import Product
from .models import Product2

admin.site.register(Product)
admin.site.register(Product2)